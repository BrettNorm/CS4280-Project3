Assignment: Project 4 - Storage=Local
Author: Brett Bax
Class: CS 4280
Teacher: Mark Hauschild


Project will be invoked as 'compfs'. ***LOCAL OPTION***

To run:

1. Run	>./make clean
2. Run	>./make
3. Two invocation methods:
	
	through pre-existing file (program adds extension .sp2022): 

		>./compfs [file]


	through keyboard input (user types input): 

		>./compfs (press ctrl+d when done to give 'EOF' to program)



- Upon success, only display the name of the target file generated and no other output. Upon error and the error message, no other display should be generated and no target should be generated.

- testFile3, testFile4, and testFile5 are good examples of the code working with loops 1 and 2
