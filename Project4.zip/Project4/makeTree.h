/*
    Prototype function for printing tree
*/

#ifndef PRINTTREE_H
#define PRINTTREE_H

#include "node.h"

using namespace std;

void treeMaker(node *);

#endif